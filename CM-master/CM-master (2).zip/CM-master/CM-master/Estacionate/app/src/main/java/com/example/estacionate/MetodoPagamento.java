package com.example.estacionate;

public class MetodoPagamento {
}
