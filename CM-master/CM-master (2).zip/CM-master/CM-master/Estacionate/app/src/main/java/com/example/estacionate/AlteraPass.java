package com.example.estacionate;

class AlteraPass {
}
