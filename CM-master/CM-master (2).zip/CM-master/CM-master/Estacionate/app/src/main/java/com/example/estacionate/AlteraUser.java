package com.example.estacionate;

class AlteraUser {
}
