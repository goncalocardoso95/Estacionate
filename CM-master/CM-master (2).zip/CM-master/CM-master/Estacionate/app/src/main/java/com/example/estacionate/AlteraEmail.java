package com.example.estacionate;

class AlteraEmail {
}
