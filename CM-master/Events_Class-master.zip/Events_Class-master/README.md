# Events_Class
Base project for CM class about events

## Exercise
- Detect a double tap
- Detect a long press
- when double tap is detected the app should enter in "erase mode", this mode changes the color of the paint to color of the background
- when a long press is detect change the background color with a random one
